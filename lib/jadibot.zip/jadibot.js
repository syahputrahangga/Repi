/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ NPM MODULE ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
require("./settings");
const {
default: makeWaSocket,
useMultiFileAuthState,
DisconnectReason,
fetchLatestBaileysVersion,
generateForwardMessageContent,
generateWAMessage,
prepareWAMessageMedia,
generateWAMessageFromContent,
generateMessageID,
downloadContentFromMessage,
makeInMemoryStore,
jidDecode,
proto
} = global.baileys; // require("@adiwajshing/baileys");
const axios = require("axios");
const { Boom } = require("@hapi/boom");
const chalk = require("chalk");
const fetch = require("node-fetch");
const figlet = require("figlet");
const FileType = require("file-type");
const fs = require("fs");
const pino = require("pino");
const log = pino;
const moment = require("moment-timezone");
const path = require("path");
const PhoneNumber = require("awesome-phonenumber");
const process = require("process");
const qrcode = require("qrcode");
const rimraf = require("rimraf");
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ CONST LIBRARY ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
const owner = global.owner;
const { color, bgcolor } = require("./lib/color");
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, writeExif } = require("./lib/exif");
const { smsg, getBuffer, fetchJson, TelegraPh, getSizeMedia, isUrl, generateMessageTag, await, sleep, reSize } = require("./lib/simple");
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' })});
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ CONST GLOBAL CONNS ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
if (global.conns instanceof Array) console.log()
else global.conns = []
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ CONTS JADIBOT ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
const jadibot = async (amores, m, from) => {
const { sendImage, sendMessage } = amores;
const { reply, sender } = m;
const { state, saveCreds } = await useMultiFileAuthState(path.join(__dirname, `./database/jadibot/${sender.split("@")[0]}`), log({ level: "silent" }));
try {
async function start() {
let { version, isLatest } = await fetchLatestBaileysVersion();
const amores = await makeWaSocket({
auth: state,
browser: [`Jadibot by Amores Bot`, "Chrome", "1.0.0"],
logger: log({ level: "silent" }),
version,
});
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ CONST ANTICALL ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
/*amores.ws.on('CB:Blocklist', json => {
if (blocked.length > 2) return
for (let i of json[1].blocklist) {
blocked.push(i.replace('c.us','s.whatsapp.net'))}})

amores.ws.on('CB:call', async (json) => {
const callerId = json.content[0].attrs['call-creator']
const idCall = json.content[0].attrs['call-id']
const Id = json.attrs.id
const T = json.attrs.t
amores.sendNode({
  tag: 'call',
    attrs: {
      from: '6285798145596@s.whatsapp.net',
      id: Id,
      t: T
    },
    content: [
      {
        tag: 'reject',
        attrs: {
          'call-creator': callerId,
          'call-id': idCall,
          count: '0'
        },
        content: null
      }
    ]
})
if (json.content[0].tag == 'offer') {
let qutsnya = await amores.sendContact(callerId, owner)
await amores.sendMessage(callerId, { text: `Sistem Otomatis Block!!!\nJangan Menelpon Bot!!!\nSilahkan Hubungi Owner Untuk Dibuka!!!`}, { quoted : qutsnya })
await sleep(8000)
await amores.updateBlockStatus(callerId, "block")
}
})*/
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ CONST MESSAGE UPSERT ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.ev.on('messages.upsert', async chatUpdate => {
try {
kay = chatUpdate.messages[0]
if (!kay.message) return
kay.message = (Object.keys(kay.message)[0] === 'ephemeralMessage') ? kay.message.ephemeralMessage.message : kay.message
if (kay.key && kay.key.remoteJid === 'status@broadcast') return
if (!amores.public && !kay.key.fromMe && chatUpdate.type === 'notify') return
if (kay.key.id.startsWith('BAE5') && kay.key.id.length === 16) return
m = smsg(amores, kay, store)
require('./amores')(amores, m, chatUpdate, store)
} catch (err) {
console.log(err)}
})
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES PUBLIC ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.public = true
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES STORE ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
store.bind(amores.ev)
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES CREDS ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.ev.on("creds.update", saveCreds)
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES CONNECTION ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.ev.on("connection.update", async up => {
const {
lastDisconnect,
connection
} = up;
if (connection == "connecting") return
if (connection){
if (connection != "connecting") console.log("Connecting to jadibot...")
}
console.log(up)
if (up.qr) await sendImage(from, await qrcode.toDataURL(up.qr, { scale : 8 }), 'Scan QR ini untuk jadi bot sementara\n\n1. Klik titik tiga di pojok kanan atas\n2. Ketuk WhatsApp Web\n3. Scan QR ini \n\nQR Expired dalam 30 detik', m)
console.log(connection)
if (connection == "open") {
amores.id = amores.decodeJid(amores.user.id)
amores.time = Date.now()
global.conns.push(amores)
await m.reply(`*Connected to Whatsapp - Bot*\n\n*User:*\n *× ID: ${amores.decodeJid(amores.user.id)}*`)
user = `${amores.decodeJid(amores.user.id)}`
txt = `*Terdeteksi menumpang Jadibot*\n\n*× User: @${user.split("@")[0]}*`
sendMessage(`${global.develover}`, { text: txt, mentions: [user] })
}
if (connection === 'close') {
let reason = new Boom(lastDisconnect?.error)?.output.statusCode
if (reason === DisconnectReason.badSession) { 
console.log(`Bad Session File, Please Delete Session and Scan Again`); amores.logout(); }
else if (reason === DisconnectReason.connectionClosed) { 
console.log("Connection closed, reconnecting...."); start(); }
else if (reason === DisconnectReason.connectionLost) { 
console.log("Connection Lost from Server, reconnecting..."); start(); }
else if (reason === DisconnectReason.connectionReplaced) { 
console.log("Connection Replaced, Another New Session Opened, Please Close Current Session First"); amores.logout(); }
else if (reason === DisconnectReason.loggedOut) { 
console.log(`Device Logged Out, Please Scan Again And Run.`); amores.logout(); }
else if (reason === DisconnectReason.restartRequired) { 
console.log("Restart Required, Restarting..."); start(); }
else if (reason === DisconnectReason.timedOut) { 
console.log("Connection TimedOut, Reconnecting..."); start(); }
else amores.end(`Unknown DisconnectReason: ${reason}|${connection}`)
}
})
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES DECODE ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES CONTACT UPDATE ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.ev.on('contacts.update', update => {
for (let contact of update) {
let id = amores.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
}
})
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES GETNAME ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.getName = (jid, withoutContact  = false) => {
id = amores.decodeJid(jid)
withoutContact = amores.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = amores.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === amores.decodeJid(amores.user.id) ?
amores.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
}
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES PARSEMENTION ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.parseMention = (text = '') => {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES SENDCONTACT ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.sendContact = async (jid, kon, quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: await amores.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await amores.getName(i + '@s.whatsapp.net')}\n
FN:${await amores.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:bayuamoreofficial@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:${global.myyt}\n
item3.X-ABLabel:YouTube\n
item4.ADR:;;Indonesia;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}
amores.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted })
}
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES SENDIMAGE ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.sendImage = async (jid, path, caption = '', quoted = '', options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await amores.sendMessage(jid, { image: buffer, caption: caption, ...options }, { quoted })
}
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES COPYNFORWARD ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.copyNForward = async (jid, message, forceForward = false, options = {}) => {
let vtype
if (options.readViewOnce) {
message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
vtype = Object.keys(message.message.viewOnceMessage.message)[0]
delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
delete message.message.viewOnceMessage.message[vtype].viewOnce
message.message = {
...message.message.viewOnceMessage.message
}
}
let mtype = Object.keys(message.message)[0]
let content = await generateForwardMessageContent(message, forceForward)
let ctype = Object.keys(content)[0]
let context = {}
if (mtype != "conversation") context = message.message[mtype].contextInfo
content[ctype].contextInfo = {
...context,
...content[ctype].contextInfo
}
const waMessage = await generateWAMessageFromContent(jid, content, options ? {
...content[ctype],
...options,
...(options.contextInfo ? {
contextInfo: {
...content[ctype].contextInfo,
...options.contextInfo
}
} : {})
} : {})
await amores.relayMessage(jid, waMessage.message, { messageId:  waMessage.key.id })
return waMessage
}
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES SEND IMAGE AS STICKER ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
 buffer = await writeExifImg(buff, options)
} else {
 buffer = await imageToWebp(buff)
}
await amores.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES SENDKATALOG ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.sendKatalog = async (jid , title = '' , desc = '', gam , options = {}) =>{
let message = await prepareWAMessageMedia({ image: gam }, { upload: amores.waUploadToServer })
const tod = generateWAMessageFromContent(jid,
{"productMessage": {
"product": {
"productImage": message.imageMessage,
"productId": "9999",
"title": title,
"description": desc,
"currencyCode": "IDR",
"priceAmount1000": "100000",
"url": `https://youtube.com/channel/UC7NslQroUqQYzo2wDFBOUMg`,
"productImageCount": 1,
"salePriceAmount1000": "0"
},
"businessOwnerJid": `6282299284898@s.whatsapp.net`
}
}, options)
return amores.relayMessage(jid, tod.message, {messageId: tod.key.id})
} 
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORE SET STATUS ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.setStatus = (status) => {
amores.query({
tag: 'iq',
attrs: {
to: '@s.whatsapp.net',
type: 'set',
xmlns: 'status',
},
content: [{
tag: 'status',
attrs: {},
content: Buffer.from(status, 'utf-8')
}]
})
return status
}
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES DOWNLOAD AND SAVE MEDIA MESSAGE ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
let type = await FileType.fromBuffer(buffer)
trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
await fs.writeFileSync(trueFileName, buffer)
return trueFileName
}
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ AMORES DOWNLOAD MEDIA MESSAGE ⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
return buffer
}
/*⫹⫺ ╳╶╼╶╶╶╶┈ ⎝ CONST SEND TEXT⎞ ┈╴╴╴╴╾╴╳ ⫹⫺*/
amores.sendText = (jid, text, quoted = '', options) => amores.sendMessage(jid, { text: text, ...options }, { quoted })

}
start()

} catch (e) {
console.log(e)
}
}

module.exports = { jadibot, conns }

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})